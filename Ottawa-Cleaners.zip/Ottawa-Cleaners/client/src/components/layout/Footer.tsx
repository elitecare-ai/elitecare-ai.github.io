import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-50 border-t border-border pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold font-heading">
              <span className="text-foreground">EliteCare</span><span className="text-primary"> Cleaning</span>
            </h3>
            <p className="text-muted-foreground">
              Professional residential and commercial cleaning services in Ottawa. Elite care for your home and office.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Facebook size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><button onClick={() => document.getElementById('services')?.scrollIntoView({behavior: 'smooth'})} className="text-muted-foreground hover:text-primary">Services</button></li>
              <li><button onClick={() => document.getElementById('pricing')?.scrollIntoView({behavior: 'smooth'})} className="text-muted-foreground hover:text-primary">Pricing</button></li>
              <li><button onClick={() => document.getElementById('testimonials')?.scrollIntoView({behavior: 'smooth'})} className="text-muted-foreground hover:text-primary">Testimonials</button></li>
              <li><button onClick={() => document.getElementById('contact')?.scrollIntoView({behavior: 'smooth'})} className="text-muted-foreground hover:text-primary">Contact Us</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Services</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li>Standard Cleaning</li>
              <li>Deep Cleaning</li>
              <li>Move-In/Move-Out</li>
              <li>Office Cleaning</li>
              <li>Post-Construction</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Contact Info</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-muted-foreground">
                <MapPin className="shrink-0 text-primary" size={20} />
                <span>302 Song Sparrow Street,<br />Ottawa ON K2J5W5</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <Phone className="shrink-0 text-primary" size={20} />
                <span>613-697-5392 / 613-698-2893</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <Mail className="shrink-0 text-primary" size={20} />
                <span>elitecarecleaning@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} EliteCare Cleaning Ottawa. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
