import { useState, useRef, useEffect } from "react";
import { MoveHorizontal } from "lucide-react";
import beforeImg from "@assets/generated_images/dirty_kitchen_counter_for_before_comparison.png";
import afterImg from "@assets/generated_images/sparkling_clean_kitchen_counter_for_after_comparison.png";

export default function BeforeAfter() {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percentage = (x / rect.width) * 100;
    setSliderPosition(percentage);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    handleMove(e.clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging.current) return;
    handleMove(e.touches[0].clientX);
  };

  // Add global event listeners for dragging outside component
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      isDragging.current = false;
    };
    window.addEventListener("mouseup", handleGlobalMouseUp);
    window.addEventListener("touchend", handleGlobalMouseUp);
    return () => {
      window.removeEventListener("mouseup", handleGlobalMouseUp);
      window.removeEventListener("touchend", handleGlobalMouseUp);
    };
  }, []);

  return (
    <section id="results" className="py-24 bg-background overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Real Results</span>
            <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-6">See the Sparkle Difference</h2>
            <p className="text-lg text-muted-foreground mb-6">
              We don't just clean; we transform spaces. Our attention to detail ensures that every corner, crevice, and surface is spotless.
            </p>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
                <span className="font-medium">Deep stain removal experts</span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
                <span className="font-medium">High-grade sanitization</span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
                <span className="font-medium">Streak-free glass & surfaces</span>
              </li>
            </ul>
          </div>

          <div 
            ref={containerRef}
            className="relative h-[400px] w-full rounded-2xl overflow-hidden cursor-ew-resize shadow-2xl select-none"
            onMouseDown={() => isDragging.current = true}
            onTouchStart={() => isDragging.current = true}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
          >
            {/* After Image (Background) */}
            <img 
              src={afterImg} 
              alt="After cleaning" 
              className="absolute inset-0 w-full h-full object-cover"
              draggable={false}
            />
            
            {/* Before Image (Clipped) */}
            <div 
              className="absolute inset-0 w-full h-full"
              style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
            >
              <img 
                src={beforeImg} 
                alt="Before cleaning" 
                className="absolute inset-0 w-full h-full object-cover"
                draggable={false}
              />
              {/* Label */}
              <div className="absolute top-4 left-4 bg-black/60 text-white text-xs font-bold px-2 py-1 rounded backdrop-blur-sm">
                BEFORE
              </div>
            </div>

            {/* After Label */}
            <div className="absolute top-4 right-4 bg-primary/80 text-white text-xs font-bold px-2 py-1 rounded backdrop-blur-sm">
              AFTER
            </div>

            {/* Slider Handle */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10 shadow-[0_0_10px_rgba(0,0,0,0.5)]"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-lg text-primary">
                <MoveHorizontal size={16} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
