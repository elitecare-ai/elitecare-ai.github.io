import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

import { Button } from "@/components/ui/button";

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-primary/5">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-primary font-semibold tracking-wider uppercase text-sm">Reviews</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">Be the first to leave us a review!</h2>
          <p className="text-muted-foreground text-lg mb-8">
            We value your feedback. Sharing your experience helps us continue to provide elite care to the Ottawa community.
          </p>
          <div className="flex justify-center gap-4">
            <Button onClick={() => document.getElementById('contact')?.scrollIntoView({behavior: 'smooth'})}>
              Leave a Review
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
