import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const plans = [
  {
    name: "Standard Clean",
    price: "120",
    description: "Perfect for maintaining a tidy home. Best for weekly or bi-weekly visits.",
    features: [
      "All surfaces dusted & wiped",
      "Floors vacuumed & mopped",
      "Kitchen & Bathroom sanitized",
      "Trash emptied",
      "Bed making"
    ],
    popular: false
  },
  {
    name: "Deep Clean",
    price: "250",
    description: "A comprehensive clean for homes that need extra attention.",
    features: [
      "Everything in Standard",
      "Inside microwave & oven",
      "Baseboards & doors detailed",
      "Light switches & handles",
      "Upholstery vacuuming"
    ],
    popular: true
  },
  {
    name: "Move-In/Out",
    price: "350",
    description: "Guaranteed to pass your landlord's inspection checklist.",
    features: [
      "Everything in Deep Clean",
      "Inside all cabinets & drawers",
      "Inside fridge & appliances",
      "Window interiors & sills",
      "Spot cleaning walls"
    ],
    popular: false
  }
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-semibold tracking-wider uppercase text-sm">Transparent Pricing</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">Simple, Flat-Rate Pricing</h2>
          <p className="text-muted-foreground text-lg">
            No hidden fees. Prices start from listed amounts and may vary based on home size and condition.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative flex flex-col ${plan.popular ? 'border-primary shadow-xl scale-105 z-10' : 'border-border shadow-sm'}`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4 flex items-baseline text-foreground">
                  <span className="text-sm font-medium text-muted-foreground mr-1">Starting from</span>
                  <span className="text-4xl font-bold">${plan.price}</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-foreground/80">
                      <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button 
                  className={`w-full ${plan.popular ? 'bg-primary hover:bg-primary/90' : ''}`} 
                  variant={plan.popular ? 'default' : 'outline'}
                  onClick={() => document.getElementById('contact')?.scrollIntoView({behavior: 'smooth'})}
                >
                  Book This Service
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
