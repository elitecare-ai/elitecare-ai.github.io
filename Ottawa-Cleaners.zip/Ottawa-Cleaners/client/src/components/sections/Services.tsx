import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, Home, Building2, Truck, CheckCircle2 } from "lucide-react";
import officeImg from "@assets/generated_images/commercial_office_cleaning_service.png";

const services = [
  {
    title: "Residential Cleaning",
    description: "Regular housekeeping to keep your home fresh and organized. Weekly, bi-weekly, or monthly.",
    icon: Home,
    features: ["Dusting & Vacuuming", "Kitchen & Bathroom sanitization", "Bed making & Tidy up", "Eco-friendly products"]
  },
  {
    title: "Deep Cleaning",
    description: "A thorough top-to-bottom clean for homes that haven't been professionally cleaned in a while.",
    icon: Sparkles,
    features: ["Baseboards & Door frames", "Inside appliances", "Grout scrubbing", "Light fixtures & Fans"]
  },
  {
    title: "Move-In / Move-Out",
    description: "Ensure you get your deposit back or walk into a fresh new home. We handle the heavy lifting.",
    icon: Truck,
    features: ["Inside cabinets & drawers", "Wall spot cleaning", "Appliance deep clean", "Window sills & tracks"]
  },
  {
    title: "Office Cleaning",
    description: "Create a productive environment for your team with our reliable commercial cleaning services.",
    icon: Building2,
    features: ["Desk & Surface sanitization", "Common area maintenance", "Restroom restocking", "Trash removal"],
    image: officeImg
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-background relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-semibold tracking-wider uppercase text-sm">Our Services</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">Cleaning Solutions for Every Need</h2>
          <p className="text-muted-foreground text-lg">
            Whether you need a quick refresh or a deep scrub, our professional team has you covered with tailored cleaning plans.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-border/50 overflow-hidden flex flex-col h-full">
              {service.image && (
                <div className="h-40 overflow-hidden">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                </div>
              )}
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-white transition-colors">
                  <service.icon className="w-6 h-6" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription className="text-base mt-2">{service.description}</CardDescription>
              </CardHeader>
              <CardContent className="mt-auto">
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
