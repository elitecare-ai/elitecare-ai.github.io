import { Button } from "@/components/ui/button";
import { ArrowRight, Phone, Star } from "lucide-react";
import heroBg from "@assets/generated_images/clean_bright_living_room_hero_background.png";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroBg} 
          alt="Clean modern living room" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/70 to-transparent md:via-white/50"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-2xl animate-in slide-in-from-left-10 duration-700 fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-foreground leading-[1.1] mb-6">
            Elite Care for a <span className="text-primary">Spotless Home</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed max-w-lg">
            Reliable, thorough, and affordable cleaning services for your home and office. We take care of the mess so you can focus on what matters.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              className="text-base h-12 px-8 shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all"
              onClick={() => document.getElementById('contact')?.scrollIntoView({behavior: 'smooth'})}
            >
              Get a Free Quote <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-base h-12 px-8 bg-white/80 backdrop-blur-sm border-primary/20 hover:bg-white"
              onClick={() => window.location.href = 'tel:6136975392'}
            >
              <Phone className="mr-2 w-4 h-4" /> 613-697-5392
            </Button>
          </div>

          <div className="mt-12 flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              Bonded & Insured
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              Eco-Friendly Products
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              100% Satisfaction Guarantee
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
